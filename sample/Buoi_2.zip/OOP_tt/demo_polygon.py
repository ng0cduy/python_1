import math


class Polygon(object):
    def __init__(self, so_canh):
        self.so_canh = so_canh
        self.canh = []

    def nhap_canh(self):
        self.canh = [int(input("Nhập cạnh thứ " + str(i + 1) + ": ")) for i in range(self.so_canh)]

    def hien_thi_canh(self):
        for i in range(self.so_canh):
            print("Cạnh " + str(i + 1) + ": " + str(self.canh[i]))


class Triangle(Polygon):
    def __init__(self):
        Polygon.__init__(self, 3)

    def tinh_chu_vi(self):
        a, b, c = self.canh
        cv = a + b + c
        return cv

    def tinh_dien_tich(self):
        a, b, c = self.canh
        nua_cv = self.tinh_chu_vi() / 2
        dt = math.sqrt(nua_cv * (nua_cv - a) * (nua_cv - b) * (nua_cv - c))
        return dt

    def in_thong_tin(self):
        print("Chu vi hình tam giác:", self.tinh_chu_vi())
        print("Diện tích hình tam giác:", self.tinh_dien_tich())

    def __del__(self):
        pass


class Rectangle(Polygon):
    def __init__(self):
        super().__init__(2)

    def tinh_chu_vi(self):
        a, b = self.canh
        cv = (a + b) * 2
        return cv

    def tinh_dien_tich(self):
        a, b = self.canh
        dt = a * b
        return dt

    def in_thong_tin(self):
        print("Chu vi hình chữ nhật:", self.tinh_chu_vi())
        print("Diện tích hình chữ nhật:", self.tinh_dien_tich())

    def __del__(self):
        pass


if __name__ == '__main__':
    while True:
        chuc_nang = int(input("\nBạn muốn in thông tin gì?\n1. Hình tam giác\n2. Hình chữ nhật\n=> "))
        if chuc_nang == 1:
            tam_giac = Triangle()
            tam_giac.nhap_canh()
            tam_giac.hien_thi_canh()
            tam_giac.in_thong_tin()

            # print(isinstance(tam_giac, Triangle))  # True

        elif chuc_nang == 2:
            hcn = Rectangle()
            hcn.nhap_canh()
            hcn.hien_thi_canh()
            hcn.in_thong_tin()

            # print(isinstance(hcn, Triangle))  # False

        else:
            print("\nChỉ được chọn 1 hoặc 2.")

        tiep_tuc = input("\nBạn có muốn tiếp tục thực hiện nữa không? (y/n)\n=> ")
        if tiep_tuc == "y" or tiep_tuc == "Y":
            continue
        else:
            break

   

    
    