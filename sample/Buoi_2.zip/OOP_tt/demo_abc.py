from abc import ABC, abstractmethod


class Animal(ABC):
    def __init__(self, _name):
        self.name = _name
    
    @abstractmethod
    def say_hi(self):
        pass


class Cat(Animal):
    def __init__(self, _name):
        super().__init__(_name)

    def say_hi(self):
        print("Hello, I'm " + self.name)


if __name__ == '__main__':
    cat_1 = Cat("Tom")
    cat_1.say_hi()