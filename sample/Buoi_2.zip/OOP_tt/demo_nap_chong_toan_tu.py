# print((2/3) + (3/4))  # 17/12

# class PhanSo:
#     def __init__(self, _tu_so, _mau_so):
#         self.tu_so = _tu_so
#         self.mau_so = _mau_so

#     def tinh_tong(self, phan_so):
#         tu_moi = self.mau_so * phan_so.tu_so + phan_so.mau_so * self.tu_so
#         mau_moi = self.mau_so * phan_so.mau_so
#         return PhanSo(tu_moi, mau_moi)

#     def in_thong_tin(self):
#         print(self.tu_so, "/", self.mau_so)
    

# if __name__ == '__main__':
#     # Khởi tạo đối tượng
#     phan_so_1 = PhanSo(2, 3)
#     phan_so_2 = PhanSo(3, 4)

#     # In thông tin
#     phan_so_1.in_thong_tin()
#     phan_so_2.in_thong_tin()

#     # Tính toán và hiển thị kết quả
#     phan_so_tong = phan_so_1.tinh_tong(phan_so_2)
#     phan_so_tong.in_thong_tin()




class PhanSo:

    __a = 100

    def __init__(self, _tu_so, _mau_so):
        self.tu_so = _tu_so
        self.mau_so = _mau_so

    def __add__(self, phan_so):
        return self.tinh_tong(phan_so)

    def tinh_tong(self, phan_so):
        tu_moi = self.mau_so * phan_so.tu_so + phan_so.mau_so * self.tu_so
        mau_moi = self.mau_so * phan_so.mau_so
        return PhanSo(tu_moi, mau_moi)

    def in_thong_tin(self):
        print(self.tu_so, "/", self.mau_so)
    

if __name__ == '__main__':
    # # Khởi tạo đối tượng
    # phan_so_1 = PhanSo(2, 3)
    # phan_so_2 = PhanSo(3, 4)

    # # In thông tin
    # phan_so_1.in_thong_tin()
    # phan_so_2.in_thong_tin()

    # # Tính toán và hiển thị kết quả
    # phan_so_tong = phan_so_1 + phan_so_2
    # phan_so_tong.in_thong_tin()

    ps = PhanSo(1, 2)
    print(ps.__a)