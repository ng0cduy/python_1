import json

f = open('du_lieu/QLCT_1.json', encoding='utf-8')
noi_dung = json.load(f)  # dict
f.close()


# CÔNG TY
cong_ty = noi_dung['CONG_TY'][0]  # dict
print("Tên công ty:", cong_ty['Ten'])
print("Địa chỉ:", cong_ty['Dia_chi'])


# ĐƠN VỊ
# Tính tổng số NV
tong = 0
don_vi = noi_dung['DON_VI']
for dv in don_vi:
    # tong = tong + int(dv['So_Nhan_vien'])
    tong += int(dv['So_Nhan_vien'])
print("Tổng số nhân viên:", tong)

print("--- Thống kê số nhân viên theo đơn vị ---")

stt = 0
for dv in don_vi:
    stt += 1
    print(str(stt), "/ Tên đơn vị:", dv['Ten'])
    print("\t- Số nhân viên:", dv['So_Nhan_vien'])
    print("\t- Tỷ lệ:", dv['Ty_le'])


