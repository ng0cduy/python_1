import json
import urllib.request

# Đọc file json từ local
# f = open('du_lieu/QLCT_1.json', encoding='utf-8')
# noi_dung = json.load(f)  # dict
# f.close()


# Đọc dữ liệu từ Internet
url = urllib.request.urlopen("http://lntpython.laptrinhpython.net:8181/dich-vu-san-pham/chi-tiet")
noi_dung = json.loads(url.read().decode())
print(noi_dung)
