# import json
# import urllib.request


# url = urllib.request.urlopen("http://lntpython.laptrinhpython.net:8181/dich-vu-san-pham/chi-tiet")
# noi_dung = json.loads(url.read().decode())
# print(noi_dung)




