import xml.dom.minidom


danh_sach = [
    {"Ten": "Tiếng chim hót trong bụi mận gai",
        "Nam_san_xuat": "1982", "The_loai": "Tình cảm",
        "Dinh_dang": "DVD"},
    {"Ten": "Chiến tranh và Hòa bình",
     "Nam_san_xuat": "1981", "The_loai": "Tình cảm, Chiến tranh",
     "Dinh_dang": "DVD"},
    {"Ten": "Người đẹp và Quái vật",
     "Nam_san_xuat": "1990", "The_loai": "Tình cảm, Hoạt hình",
     "Dinh_dang": "VHS"}]


tai_lieu = xml.dom.minidom.Document()

# TẠO NODE ROOT
node_root = tai_lieu.createElement('DANH_SACH')
tai_lieu.appendChild(node_root)

for phim in danh_sach:
    # Gán biến
    ten_phim = phim["Ten"]
    nam_san_xuat = phim["Nam_san_xuat"]
    the_loai = phim["The_loai"]
    dinh_dang = phim["Dinh_dang"]

    # TẠO NODE CON
    # Tạo node PHIM
    node_phim = tai_lieu.createElement("PHIM")
    node_root.appendChild(node_phim)
    # Gán dữ liệu
    node_phim.setAttribute("Nam_san_xuat", nam_san_xuat)
    node_phim.setAttribute("Ten", ten_phim)

    # Tạo node The_loai
    node_the_loai = tai_lieu.createElement("The_loai")
    node_phim.appendChild(node_the_loai)
    # Gán dữ liệu
    node_the_loai.appendChild(tai_lieu.createTextNode(the_loai))

    # Tạo node Dinh_dang
    node_dinh_dang = tai_lieu.createElement("Dinh_dang")
    node_phim.appendChild(node_dinh_dang)
    # Gán dữ liệu
    node_dinh_dang.appendChild(tai_lieu.createTextNode(dinh_dang))

f = open("du_lieu/files_xml/phim_moi.xml", "w", encoding="utf-8")
tai_lieu.writexml(f, newl="\n", addindent="\t")

