import json

# sv_1 = {"MSSV": "SV001", "Ho_ten": "Sinh viên 1", "SDT": "0909090909"}
# sv_2 = {"MSSV": "SV002", "Ho_ten": "Sinh viên 2", "SDT": "0909123456"}
#
# ds_sinh_vien = [sv_1, sv_2]
# ds_sinh_vien.append(sv_1)
# ds_sinh_vien.append(sv_2)


# f = open('du_lieu/ds_sinh_vien.json', 'w', encoding='utf-8')
# json.dump(ds_sinh_vien, f, ensure_ascii=False, indent=4)
# f.close()


ds_sinh_vien = []
while True:
    mssv = input("Nhập mã số SV: ")
    ho_ten = input("Nhập họ tên: ")
    sdt = input("Nhập số điện thoại: ")
    sv = {"MSSV": mssv, "Ho_ten": ho_ten, "SDT": sdt}
    ds_sinh_vien.append(sv)

    tiep_tuc = input("Bạn có muốn tiếp tục không? (y/n)\n=> ")
    if tiep_tuc == "y" or tiep_tuc == "Y":
        continue
    else:
        break





