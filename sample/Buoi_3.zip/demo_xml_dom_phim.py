from xml.dom.minidom import parse


tai_lieu = parse("du_lieu/files_xml/phim.xml")
node_root = tai_lieu.documentElement

phim_s = node_root.getElementsByTagName("PHIM")

for phim in phim_s:
    nam_san_xuat = phim.getAttribute("Nam_san_xuat")
    ten = phim.getAttribute("Ten")
    the_loai = phim.getElementsByTagName("The_loai")[0]
    dinh_dang = phim.getElementsByTagName("Dinh_dang")[0]

    print("Tên phim:", ten)
    print("Năm sản xuất:", nam_san_xuat)
    print("Thể loại:", the_loai.childNodes[0].data)
    print("Định dạng:", dinh_dang.childNodes[0].data)
    print()

