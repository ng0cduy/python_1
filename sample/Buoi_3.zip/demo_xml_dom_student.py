from xml.dom.minidom import parse


tai_lieu = parse('du_lieu/files_xml/student.xml')
node_root = tai_lieu.documentElement

students = node_root.getElementsByTagName("student")

for student in students:
    ids = student.getAttribute("id")
    print("ID:", ids)

    name = student.getElementsByTagName("name")[0]
    print("Name:", name.childNodes[0].data)

    date = student.getElementsByTagName("date")[0]
    print("Date:", date.childNodes[0].data)

    print()

