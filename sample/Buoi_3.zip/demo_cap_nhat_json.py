from thu_vien.Xu_ly_Chung import *

duong_dan = "du_lieu/ds_sinh_vien.json"
ds_sinh_vien = doc_file_json(duong_dan)
print(ds_sinh_vien)

while True:
    mssv = input("Nhập mã số SV: ")
    ho_ten = input("Nhập họ tên: ")
    sdt = input("Nhập số điện thoại: ")
    sv = {"MSSV": mssv, "Ho_ten": ho_ten, "SDT": sdt}
    ds_sinh_vien.append(sv)

    tiep_tuc = input("Bạn có muốn tiếp tục không? (y/n)\n=> ")
    if tiep_tuc == "y" or tiep_tuc == "Y":
        continue
    else:
        break

kq = ghi_file_json(duong_dan, ds_sinh_vien)
if kq:
    print("Cập nhật dữ liệu thành công.")
else:
    print("Cập nhật dữ liệu thất bại.")


