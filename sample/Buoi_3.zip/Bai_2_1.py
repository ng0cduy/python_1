import json
import urllib.request
import csv


url = urllib.request.urlopen("http://lntpython.laptrinhpython.net:8181/dich-vu-san-pham/chi-tiet")
noi_dung = json.loads(url.read().decode())  # list
# print(noi_dung)

tieu_de = "DANH SÁCH SẢN PHẨM (" + str(len(noi_dung)) + ")"
print(tieu_de.center(110))
print("STT".ljust(7), "TÊN SẢN PHẨM".ljust(30), "HÌNH SẢN PHẨM".ljust(40), "GIÁ SIZE S".ljust(15), "GIÁ SIZE M".ljust(15))
print("-" * 110)

stt = 0
list_sp = []
for san_pham in noi_dung:
    stt += 1
    print(str(stt).ljust(7), san_pham['ten_san_pham'].ljust(30), san_pham['hinh_san_pham'].ljust(40),
          str(san_pham['gia_size_s']).ljust(15), str(san_pham['gia_size_m']).ljust(15))

    # Tạo list sp để ghi file csv
    sp = [san_pham['ten_san_pham'], san_pham['hinh_san_pham'], san_pham['gia_size_s'], san_pham['gia_size_m']]
    list_sp.append(sp)

# Ghi ra file csv
f = open('du_lieu/dssp.csv', 'w', encoding='utf-8', newline='')
for sp in list_sp:
    csv.writer(f).writerow(sp)
f.close()



