import json


def doc_file_json(duong_dan):
    f = open(duong_dan, encoding="utf-8")
    noi_dung = json.load(f)
    f.close()
    return noi_dung


def ghi_file_json(duong_dan, noi_dung):
    f = open(duong_dan, "w", encoding="utf-8")
    json.dump(noi_dung, f, ensure_ascii=False, indent=4)
    f.close()
    return True
