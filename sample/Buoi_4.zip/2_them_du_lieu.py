import sqlite3


# Khởi tạo kết nối CSDL
conn = sqlite3.connect('du_lieu/ql_nhan_vien.db')
print("Kết nối CSDL thành công.")


# Truy vấn
# # Cách 1
# chuoi_sql = "INSERT INTO NhanVien (Ma_so, Ho_ten, CMND, SDT, Dia_chi) " \
#             "VALUES ('NV04', 'Nhân viên 4', '159753123', '0903987123', 'Long An')"
# conn.execute(chuoi_sql)
# conn.commit()

# # Cách 2
# chuoi_sql = "INSERT INTO NhanVien (Ma_so, Ho_ten, CMND, SDT, Dia_chi) VALUES (?, ?, ?, ?, ?)"
# conn.execute(chuoi_sql, ("NV05", "Nhân viên 5", "456753159", "0918321654", "TPHCM"))
# conn.commit()

# Cách 3
chuoi_sql = "INSERT INTO NhanVien VALUES (null, ?, ?, ?, ?, ?)"
conn.execute(chuoi_sql, ("NV05", "Nhân viên 5", "456753159", "0918321654", "TPHCM"))
conn.commit()


# Ngắt kết nối CSDL
conn.close()
