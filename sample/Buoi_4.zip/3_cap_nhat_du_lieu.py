import sqlite3


# Khởi tạo kết nối CSDL
conn = sqlite3.connect('du_lieu/ql_nhan_vien.db')
print("Kết nối CSDL thành công.")


# Truy vấn
chuoi_sql = "UPDATE NhanVien SET Ma_so=?, Ho_ten=? WHERE ID=?"
conn.execute(chuoi_sql, ("NV06", "Nhân viên 6", 6))
conn.commit()


# Ngắt kết nối CSDL
conn.close()

