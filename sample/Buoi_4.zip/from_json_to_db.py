from thu_vien.Xu_ly_Chung import *
import os
import sqlite3


conn = sqlite3.connect('du_lieu/ql_tivi.db')
print("Kết nối CSDL thành công.")


duong_dan_thu_muc_tivi = "du_lieu/Tivi/"
for tap_tin in os.listdir(duong_dan_thu_muc_tivi):
    # Đọc file json
    noi_dung = doc_file_json(duong_dan_thu_muc_tivi + tap_tin)

    # Gán biến
    ma_so = noi_dung['Ma_so']
    ten = noi_dung['Ten']
    ky_hieu = noi_dung['Ky_hieu']
    don_gia_ban = noi_dung['Don_gia_Ban']
    don_gia_nhap = noi_dung['Don_gia_Nhap']
    so_luong_ton = noi_dung['So_luong_Ton']
    nhom_tivi = noi_dung['Nhom_Tivi']['Ma_so']

    # Khai báo câu lệnh truy vấn
    chuoi_sql = "INSERT INTO Tivi VALUES(?, ?, ?, ?, ?, ?, ?)"
    conn.execute(chuoi_sql, (ma_so, ten, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi))
    conn.commit()
    print("Đã ghi " + ma_so)

print("Đã thêm vào CSDL thành công.")
conn.close()



