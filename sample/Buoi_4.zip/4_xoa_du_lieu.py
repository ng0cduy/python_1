import sqlite3


# Khởi tạo kết nối CSDL
conn = sqlite3.connect('du_lieu/ql_nhan_vien.db')
print("Kết nối CSDL thành công.")


# Truy vấn
chuoi_sql = "DELETE FROM NhanVien WHERE ID=?"
conn.execute(chuoi_sql, (6,))
conn.commit()


# Ngắt kết nối CSDL
conn.close()

