from xml.dom.minidom import parse


class DonVi:
    """
    classdocs: Đơn vị
    """
    def __init__(self, _iddv, _ten):
        self.iddv = _iddv
        self.ten = _ten


class NhanVien:
    """
    classdocs: Nhân viên
    """
    def __init__(self, _idnv, _ho_ten, _gioi_tinh, _ngay_sinh, _cmnd, _muc_luong, _dia_chi, _iddv):
        self.idnv = _idnv
        self.ho_ten = _ho_ten
        self.gioi_tinh = _gioi_tinh
        self.ngay_sinh = _ngay_sinh
        self.cmnd = _cmnd
        self.muc_luong = _muc_luong
        self.dia_chi = _dia_chi
        self.iddv = _iddv

    def in_thong_tin(self):
        gioi_tinh = 'Nữ'
        if self.gioi_tinh == 'true':
            gioi_tinh = 'Nam'

        chuoi_kq = "- ID Nhân viên: " + self.idnv
        chuoi_kq += "- Họ tên: " + self.ho_ten
        chuoi_kq += "- Giới tính: " + gioi_tinh
        chuoi_kq += "- Ngày sinh: " + self.ngay_sinh
        chuoi_kq += "- CMND: " + self.cmnd
        chuoi_kq += "- Mức lương: " + self.muc_luong
        chuoi_kq += "- Địa chỉ: " + self.dia_chi
        chuoi_kq += "- ID Đơn vị: " + self.iddv
        print(chuoi_kq)


def tao_danh_sach_don_vi(ds_don_vi, duong_dan):
    tai_lieu = parse(duong_dan)
    node_root = tai_lieu.documentElement
    don_vi_s = node_root.getElementsByTagName("DON_VI")
    for don_vi in don_vi_s:
        if don_vi.hasAttribute("ID") and don_vi.hasAttribute("Ten"):
            dv = DonVi(don_vi.getAttribute("ID"), don_vi.getAttribute("Ten"))
            ds_don_vi.append(dv)
    return ds_don_vi


def tao_danh_sach_nhan_vien(ds_nhan_vien, duong_dan):
    tai_lieu = parse(duong_dan)
    node_root = tai_lieu.documentElement
    nhan_vien_s = node_root.getElementsByTagName("NHAN_VIEN")
    for nhan_vien in nhan_vien_s:
        nv = NhanVien(nhan_vien.getAttribute("ID"), nhan_vien.getAttribute("Ho_ten"),
                      nhan_vien.getAttribute("Gioi_tinh"), nhan_vien.getAttribute("Ngay_sinh"),
                      nhan_vien.getAttribute("CMND"), nhan_vien.getAttribute("Muc_luong"),
                      nhan_vien.getAttribute("Dia_chi"), nhan_vien.getAttribute("ID_DON_VI"))
        ds_nhan_vien.append(nv)
    return ds_nhan_vien


def thong_ke_nhan_vien_theo_don_vi(iddv, ds_nhan_vien):
    tong_nv = 0
    nv_nam = 0
    nv_nu = 0
    ds_nhan_vien_theo_dv = []
    for nhan_vien in ds_nhan_vien:
        if nhan_vien.iddv == iddv:
            # Thêm nhân viên vào danh sách mới nếu thỏa điều kiện
            ds_nhan_vien_theo_dv.append(nhan_vien)

            # Đếm tổng nhân viên theo đơn vị
            tong_nv += 1
            # Thống kê nhân viên theo giới tính
            if nhan_vien.gioi_tinh == "true":
                nv_nam += 1
            else:
                nv_nu += 1
    return ds_nhan_vien_theo_dv, tong_nv, nv_nam, nv_nu  # tuple


def tim_kiem_nhan_vien(tu_khoa, ds_nhan_vien):
    ds_tim_kiem = []
    for nhan_vien in ds_nhan_vien:
        if nhan_vien.ho_ten.lower().find(tu_khoa.lower()) != -1:
            ds_tim_kiem.append(nhan_vien)
    return ds_tim_kiem


def in_danh_sach_nhan_vien(danh_sach):
    tieu_de = "DANH SÁCH NHÂN VIÊN (" + str(len(danh_sach)) + ")"
    print(tieu_de)
    print("ID".ljust(7), "Tên NV".ljust(25), "Giới tính".ljust(15), "Ngày sinh".ljust(20), "CMND".ljust(15),
          "Mức lương".ljust(15), "Địa chỉ".ljust(50), "ID Đơn vị".ljust(7))
    print("-" * 165)
    for nhan_vien in danh_sach:
        gt = "Nữ"
        if nhan_vien.gioi_tinh == "true":
            gt = "Nam"

        print(nhan_vien.idnv.ljust(7), nhan_vien.ho_ten.ljust(25), gt.ljust(15),
              nhan_vien.ngay_sinh.ljust(20), nhan_vien.cmnd.ljust(15), nhan_vien.muc_luong.ljust(15),
              nhan_vien.dia_chi.ljust(50), nhan_vien.iddv.ljust(7))


if __name__ == '__main__':
    """
    1. In danh sách đơn vị
    2. In danh sách nhân viên
    3. Thống kê nhân viên theo đơn vị
    4. Tìm kiếm nhân viên
    """
    # Đơn vị
    list_don_vi = []
    duong_dan_dv = "du_lieu/don_vi.xml"
    list_don_vi = tao_danh_sach_don_vi(list_don_vi, duong_dan_dv)

    # Nhân viên
    list_nhan_vien = []
    duong_dan_nv = "du_lieu/nhan_vien.xml"
    list_nhan_vien = tao_danh_sach_nhan_vien(list_nhan_vien, duong_dan_nv)

    while True:
        chuc_nang = int(input("\nBạn muốn làm gì?\n1. In danh sách đơn vị\n2. In danh sách nhân viên"
                              "\n3. Thống kê nhân viên theo đơn vị\n4. Tìm kiếm nhân viên\n=> "))
        if chuc_nang == 1:
            tieu_de = "DANH SÁCH ĐƠN VỊ (" + str(len(list_don_vi)) + ")"
            print(tieu_de)
            print("ID".ljust(7), "Tên ĐV".ljust(20))
            print("-" * 20)
            for don_vi in list_don_vi:
                print(don_vi.iddv.ljust(7), don_vi.ten.ljust(20))

        elif chuc_nang == 2:
            in_danh_sach_nhan_vien(list_nhan_vien)

        elif chuc_nang == 3:
            # Hiển thị danh sách đơn vị (Giống như chức năng 1)
            tieu_de = "DANH SÁCH ĐƠN VỊ (" + str(len(list_don_vi)) + ")"
            print(tieu_de)
            print("ID".ljust(7), "Tên ĐV".ljust(20))
            print("-" * 20)
            for don_vi in list_don_vi:
                print(don_vi.iddv.ljust(7), don_vi.ten.ljust(20))

            # Nhập iddv muốn thống kê
            iddv = input("Nhập ID đơn vị: ")

            # Gán biến từ hàm thong_ke_nhan_vien_theo_don_vi
            ds_nv_theo_dv = thong_ke_nhan_vien_theo_don_vi(iddv, list_nhan_vien)[0]  # list
            tong_nv = thong_ke_nhan_vien_theo_don_vi(iddv, list_nhan_vien)[1]  # giá trị
            nv_nam = thong_ke_nhan_vien_theo_don_vi(iddv, list_nhan_vien)[2]  # giá trị
            nv_nu = thong_ke_nhan_vien_theo_don_vi(iddv, list_nhan_vien)[3]  # giá trị

            # Hiển thị danh sách nhân viên sau khi thống kê (Giống như chức năng 2)
            in_danh_sach_nhan_vien(ds_nv_theo_dv)

            # Thống kê
            print("Tổng số nhân viên:", tong_nv, "(Trong đó có", nv_nam, "nam và", nv_nu, "nữ).")

        elif chuc_nang == 4:
            # Nhập từ khóa
            tu_khoa = input("Nhập họ tên cần tìm: ")

            # Lấy danh sách tìm được từ hàm tim_kiem_nhan_vien
            ds_tim_kiem = tim_kiem_nhan_vien(tu_khoa, list_nhan_vien)

            # Hiển thị danh sách nhân viên sau khi tìm (Giống chức năng 2)
            in_danh_sach_nhan_vien(ds_tim_kiem)

        else:
            print("\nChỉ được chọn 1, 2, 3 hoặc 4.")

        tiep_tuc = input("\nBạn có muốn tiếp tục? (y/n)\n=> ").lower()
        if tiep_tuc == "y":
            continue
        else:
            break
