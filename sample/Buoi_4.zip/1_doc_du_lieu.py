import sqlite3


# Khởi tạo kết nối đến db
conn = sqlite3.connect('du_lieu/ql_nhan_vien.db')
print("Kết nối CSDL thành công.")


# Câu lệnh truy vấn
# chuoi_sql = "SELECT Ma_so, Ho_ten, CMND, SDT, Dia_chi FROM NhanVien"
chuoi_sql = "SELECT * FROM NhanVien"
noi_dung = conn.execute(chuoi_sql)

for dong in noi_dung:
    print(dong)

# Ngắt kết nối với CSDL
conn.close()


