import re


email = input("Nhập email: ")
kq = re.match(r'^([A-Z0-9._-])+@([A-Z0-9._-])+\b.([A-Z]{2,})$', email, re.I | re.M)
if kq:
    print("Email hợp lệ")
else:
    print("Email không hợp lệ")


