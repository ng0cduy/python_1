import re


def kiem_tra_match(pattern, string):
    kq = re.match(pattern, string, re.I | re.M)
    if kq:
        print("Match !")
    else:
        print("No match !")


# =================== DẤU NGOẶC VUÔNG [] ===================
# Dùng để thể hiện tập các KÝ TỰ mà bạn muốn khớp
# kiem_tra_match(r'[a-c]', 'abc')
# kiem_tra_match(r'[a-c]', 'adef')
# kiem_tra_match(r'[a-c]', 'dea')

# =================== DẤU CHẤM . ===================
# Khớp với bất kì KÝ TỰ ĐƠN thông thường ngoại trừ kí tự xuống dòng \n
# kiem_tra_match(r'.', 'a')
# kiem_tra_match(r'..', 'a')
# kiem_tra_match(r'..', 'abc')

# =================== DẤU MŨ ^ ===================
# Dùng để kiểm tra khớp với KÝ TỰ ĐỨNG ĐẦU của 1 chuỗi
# kiem_tra_match(r'^a', 'abc')
# kiem_tra_match(r'^a', 'cba')
# kiem_tra_match(r'^ac', 'acc')
# kiem_tra_match(r'^a.', 'acc')

# =================== DẤU DOLLAR $ ===================
# Dùng để kiểm tra khớp với KÝ TỰ KẾT THÚC của 1 chuỗi
# kiem_tra_match(r'a$', 'a')
# kiem_tra_match(r'..a$', 'cba')
# kiem_tra_match(r'..a$', 'cbd')
# kiem_tra_match(r'.*a$', 'DFGDFGDRERGERcba')


# =================== DẤU HOA THỊ * ===================
# Có thể khớp với chuỗi CÓ hoặc KHÔNG CÓ KÝ TỰ được định nghĩa đứng trước nó
# KÝ TỰ có thể lặp lại nhiều lần mà KHÔNG giới hạn số lượng
# kiem_tra_match(r'.*a$', 'a')
# kiem_tra_match(r'ma*n', 'maman')
# kiem_tra_match(r'a*n', 'aaaaaaaan')


# =================== DẤU CHẤM HỎI ? ===================
# Có thể khớp với chuỗi CÓ hoặc KHÔNG CÓ KÝ TỰ được định nghĩa đứng trước nó
# KÝ TỰ này KHÔNG THỂ lặp lại nhiều lần, mà sẽ bị GIỚI HẠN số lượng là MỘT lần
# kiem_tra_match(r'ma?n', 'man')
# kiem_tra_match(r'ma?n', 'maan')
# kiem_tra_match(r'ma?n', 'woman')
# kiem_tra_match(r'a?n', 'aaaaaan')

# =================== DẤU CỘNG + ===================
# Có thể khớp với chuỗi CÓ MỘT hoặc NHIỀU KÝ TỰ được định nghĩa đứng trước nó
# KÝ TỰ có thể lặp lại nhiều lần mà KHÔNG giới hạn số lượng
# kiem_tra_match(r'ma+n', 'man')
# kiem_tra_match(r'a+n', 'aaaaaaaaan')
# kiem_tra_match(r'a+n', 'an')
# kiem_tra_match(r'.+n', 'n')


# =================== DẤU NGOẶC NHỌN {} ===================
# Sử dụng theo công thức {n,m}: đại diện cho KÝ TỰ đứng trước nó có thể
# xuất hiện tối thiểu n lần và tối đa m lần (với n, m là số nguyên dương)
# - Nếu n bỏ trống {,m}: thì giá trị n mặc định bằng 0
# - nếu m bỏ trống {n,}: thì giá trị m mặc định bằng vô hạn
# kiem_tra_match(r'b{2,4}', 'bac')
# kiem_tra_match(r'b{2,4}', 'bbac')
# kiem_tra_match(r'b{2,4}', 'acbb')
# kiem_tra_match(r'..b{2,4}', 'acbb')


# =================== DẤU SỔ DỌC | ===================
# Dấu sổ dọc có thể khớp với chuỗi tồn tại 1 trong 2 KÝ TỰ được định nghĩa trước và sau nó
# kiem_tra_match(r'(a|b|c)', 'bdef')
# kiem_tra_match(r'def(a|b|c)', 'defa')


# =================== DẤU NGOẶC ĐƠN () ===================
# Được sử dụng để gom nhóm các partern lại với nhau, chuỗi sẽ khớp với biểu thức chính quy 
# bên trong dấu ngoặc này
# kiem_tra_match(r'(a|b|c).*', 'abc def')


# =================== DẤU GẠCH CHÉO NGƯỢC \ ===================
# =================== \A Khớp với các KÝ TỰ theo sau nó nằm ở đầu chuỗi ===================
# kiem_tra_match(r'\Athe', 'the sun')
# kiem_tra_match(r'^the', 'the sun')


# =================== \Z Khớp với các KÝ TỰ đứng trước nó nằm ở cuối chuỗi ===================
# kiem_tra_match(r'.*sun\Z', 'the sun')
# kiem_tra_match(r'in\Z', 'in the sun')


# =================== \b Khớp với các KÝ TỰ được chỉ định nằm ở đầu và cuối của CHUỖI ===================
# kiem_tra_match(r'\bfoo', 'football')
# kiem_tra_match(r'\bfoo', 'a football')
# kiem_tra_match(r'.*foo\b', 'the foo')
# kiem_tra_match(r'.*foo\b', 'the afoo')


# =================== \B Khớp với các KÝ TỰ được chỉ định KHÔNG nằm ở đầu và cuối của TỪ đầu tiên trong CHUÔI ===================
# kiem_tra_match(r'\Bfoo', 'football')
# kiem_tra_match(r'.*\Bfoo', 'acfootb')


# =================== \d Khớp với các KÝ TỰ là CHỮ SỐ, tương đương với [0-9] ===================
# kiem_tra_match(r'\d', '123456')
# kiem_tra_match(r'\d', '123abc456')
# kiem_tra_match(r'.\d', 'a23abc456')


# =================== \D Khớp với các KÝ TỰ là KHÔNG LÀ SỐ, tương đương với [^0-9] ===================
# kiem_tra_match(r'\D', '123456')
# kiem_tra_match(r'\D', '123abc456')
# kiem_tra_match(r'\D', 'a23abc456')


# =================== \w Khớp với các KÝ TỰ chữ cái hoặc chữ số, tương đương [a-zA-Z0-9_] ===================
# kiem_tra_match(r'\w', '123456def@')
# kiem_tra_match(r'\w', '$123456def@')
# kiem_tra_match(r'\w', '_sdfsd123')
# kiem_tra_match(r'\w', '-sdfsd123')


# =================== \W Khớp với các KÝ TỰ KHÔNG PHẢI LÀ chữ cái hoặc chữ số, tương đương [^a-zA-Z0-9_] ===================
# kiem_tra_match(r'\W', '@')
# kiem_tra_match(r'\W', '@gmail.com')
# kiem_tra_match(r'\W', '%$#@')

