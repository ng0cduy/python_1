import re

line = "The wheel on the bus go round and round, round and round, round and round"

# Match
# matchObj = re.match(r"(.*) go (.*?) .*", line, re.M | re.I)
matchObj = re.match(r"round", line, re.M | re.I)
if matchObj:
    print("matchObj.group():", matchObj.group())
    # print("matchObj.group(1):", matchObj.group(1))
    # print("matchObj.group(2):", matchObj.group(2))
    # print("matchObj.groups():", matchObj.groups())
else:
    print("No match")


# searchObj = re.search(r"(.*) go (.*?) .*", line, re.M | re.I)
searchObj = re.search(r"round", line, re.M | re.I)
if searchObj:
    print("searchObj.group():", searchObj.group())
    # print("searchObj.group(1):", searchObj.group(1))
    # print("searchObj.group(2):", searchObj.group(2))
    # print("searchObj.groups():", searchObj.groups())
else:
    print("Nothing found.")

