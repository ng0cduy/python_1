import re


line = "There are five apples on the table."
print(re.findall(r'\b\w{5}\b', line))
