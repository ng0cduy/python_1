import re


phone = "(08) 38-351056 # This is Phone Number"

num = re.sub(r'#.*$', '', phone)

print(num)

num = re.sub(r'[^0-9]', '', phone)
print(num)