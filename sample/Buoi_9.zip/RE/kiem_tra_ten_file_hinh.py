import re


ten_file = input("Nhập tên tập tin: ")
kq = re.match(r'^([A-Z0-9._-]{3,})+\b.(jpg|png|gif|jpeg)$', ten_file, re.I | re.M)
if kq:
    print("Tập tin hợp lệ")
else:
    print("Tập tin không hợp lệ")
