from demo_testing import *
import unittest
from math import pi


class TestCircle(unittest.TestCase):
    def test_area(self):
        self.assertAlmostEqual(dien_tich_hinh_tron(1), pi)
        # self.assertAlmostEqual(dien_tich_hinh_tron(0), 0)
        self.assertAlmostEqual(dien_tich_hinh_tron(2.1), pi * (2.1 ** 2))

    def test_values(self):
        self.assertRaises(ValueError, dien_tich_hinh_tron, -1)

    def test_types(self):
        self.assertRaises(TypeError, dien_tich_hinh_tron, 2+4j)
        self.assertRaises(TypeError, dien_tich_hinh_tron, True)
        self.assertRaises(TypeError, dien_tich_hinh_tron, 'ban kinh')


if __name__ == "__main__":
    unittest.main()

