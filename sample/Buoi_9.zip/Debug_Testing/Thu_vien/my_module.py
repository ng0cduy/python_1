def tinh_toan(a, b):
    tong = a + b
    hieu = a - b
    return tong, hieu

