from Thu_vien.my_module import *
import pdb


if __name__ == '__main__':
    pdb.set_trace()
    print("My program")
    kq = tinh_toan(6, 3)
    print(kq)

