from math import pi


def dien_tich_hinh_tron(r):
    if r <= 0:
        raise ValueError("Bán kính không được <= 0")
    elif type(r) not in [int, float]:
        raise TypeError("Chỉ được sử dụng kiểu int hoặc float")
    return pi * (r ** 2)


# ds_ban_kinh = [2, 0, -3, 2 + 4j, True, 'ban kinh']
# thong_bao = "Diện tích hình tròn với bán kính = {ban_kinh} là: {dien_tich}"
#
# for r in ds_ban_kinh:
#     S = dien_tich_hinh_tron(r)
#     print(thong_bao.format(ban_kinh=r, dien_tich=S))

print(dien_tich_hinh_tron(-3))