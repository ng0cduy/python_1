# Đường dẫn DB
duong_dan_cong_ty = "du_lieu/ql_cong_ty.db"
duong_dan_tivi = "du_lieu/ql_tivi.db"
duong_dan_nhan_vien = "du_lieu/ql_nhan_vien_2.db"
