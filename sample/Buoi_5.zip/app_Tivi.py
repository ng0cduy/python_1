from thu_vien.c_Tivi import *

duong_dan_db = 'du_lieu/ql_tivi.db'
xl_tivi = Tivi(duong_dan_db)  # Khởi tạo đối tượng Tivi

# Lấy danh sách mã số
ds_ma_so = []
for tivi in xl_tivi.doc_danh_sach_tivi():
    ds_ma_so.append(tivi['Ma_so'])


while True:
    chuc_nang = int(input("\nBạn muốn làm gì?\n1. Xem danh sách Tivi\n2. Thêm Tivi mới"
                          "\n3. Cập nhật Tivi\n4. Xóa Tivi\n5. Tìm kiếm Tivi\n=> "))
    if chuc_nang == 1:
        print("MÃ SỐ".ljust(10), "TÊN".ljust(50), "KÝ HIỆU".ljust(15), "ĐƠN GIÁ NHẬP".rjust(20),
              "ĐƠN GIÁ BÁN".rjust(20), "SL TỒN".center(10), "NHÓM TIVI".ljust(15))
        print("-" * 140)
        ds_tivi = xl_tivi.doc_danh_sach_tivi()
        for tivi in ds_tivi:
            print(tivi['Ma_so'].ljust(10), tivi['Ten'].ljust(50), tivi['Ky_hieu'].ljust(15),
                  "{:,}".format(tivi['Don_gia_Nhap']).rjust(20), "{:,}".format(tivi['Don_gia_Ban']).rjust(20),
                  str(tivi['So_luong_Ton']).center(10), tivi['Nhom_Tivi'].ljust(15))

    elif chuc_nang == 2:
        ma_so = input("Mã số Tivi: ")
        ten_tivi = input("Tên Tivi: ")
        ky_hieu = input("Ký hiệu: ")
        don_gia_ban = int(input("Đơn giá bán: "))
        don_gia_nhap = int(input("Đơn giá nhập: "))
        so_luong_ton = int(input("Số lượng tồn: "))
        nhom_tivi = input("Nhóm Tivi: ")
        kq = xl_tivi.them_tivi(ma_so, ten_tivi, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi)
        if kq != 0:
            print("\nThêm dữ liệu thành công.")
        else:
            print("\nThêm dữ liệu thất bại.")

    elif chuc_nang == 3:
        # Kiểm tra mã số nhập vào có tồn tại không?
        ma_so = input("Nhập mã số muốn cập nhật: ")
        if ma_so in ds_ma_so:
            ten_tivi = input("Tên Tivi: ")
            ky_hieu = input("Ký hiệu: ")
            don_gia_ban = int(input("Đơn giá bán: "))
            don_gia_nhap = int(input("Đơn giá nhập: "))
            so_luong_ton = int(input("Số lượng tồn: "))
            nhom_tivi = input("Nhóm Tivi: ")
            kq = xl_tivi.cap_nhat_tivi(ma_so, ten_tivi, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi)
            if kq != 0:
                print("\nCập nhật dữ liệu thành công.")
            else:
                print("\nCập nhật dữ liệu thất bại.")
        else:
            print("\nMã số không tồn tại. Vui lòng kiểm tra lại.")

    elif chuc_nang == 4:
        ma_so = input("Nhập mã số cần xóa: ")
        if ma_so in ds_ma_so:
            kq = xl_tivi.xoa_tivi(ma_so)
            if kq != 0:
                print("\nXóa dữ liệu thành công.")
            else:
                print("\nXóa dữ liệu thất bại.")
        else:
            print("\nMã số không tồn tại. Không xóa được.")

    elif chuc_nang == 5:
        tu_khoa = input("Nhập tên tivi muốn tìm: ")
        ds_tivi = xl_tivi.tim_kiem_tivi(tu_khoa)

        print()
        print("DANH SÁCH SẢN PHẨM (" + str(len(ds_tivi)) + ")")
        print("MÃ SỐ".ljust(10), "TÊN".ljust(50), "KÝ HIỆU".ljust(15), "ĐƠN GIÁ NHẬP".rjust(20),
              "ĐƠN GIÁ BÁN".rjust(20), "SL TỒN".center(10), "NHÓM TIVI".ljust(15))
        print("-" * 140)
        for tivi in ds_tivi:
            print(tivi['Ma_so'].ljust(10), tivi['Ten'].ljust(50), tivi['Ky_hieu'].ljust(15),
                  "{:,}".format(tivi['Don_gia_Nhap']).rjust(20), "{:,}".format(tivi['Don_gia_Ban']).rjust(20),
                  str(tivi['So_luong_Ton']).center(10), tivi['Nhom_Tivi'].ljust(15))

    else:
        print("\nChỉ được chọn 1, 2, 3, 4 hoặc 5.")

    tiep_tuc = input("\nBạn có muốn tiếp tục nữa không? (y/n)\n=> ").lower().strip()
    if tiep_tuc == "y":
        continue
    else:
        break

# Ngắt kết nối
xl_tivi.disconnect()
