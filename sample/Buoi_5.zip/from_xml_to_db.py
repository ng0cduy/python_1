from xml.dom.minidom import parse
import sqlite3

# Khởi tạo kết nối DB
conn = sqlite3.connect('du_lieu/ql_nhan_vien.db')

# Đơn vị
# tai_lieu = parse('du_lieu/don_vi.xml')
# node_root = tai_lieu.documentElement
# don_vi_s = node_root.getElementsByTagName('DON_VI')
# for don_vi in don_vi_s:
#     _id = don_vi.getAttribute('ID')
#     ten = don_vi.getAttribute('Ten')
#
#     # Thực hiện đưa DL vào DB
#     chuoi_sql = 'INSERT INTO DonVi VALUES (?, ?)'
#     conn.execute(chuoi_sql, (_id, ten))
#     conn.commit()
#
#     print('Đã ghi ' + ten)


# Nhân viên
tai_lieu = parse('du_lieu/nhan_vien.xml')
node_root = tai_lieu.documentElement
nhan_vien_s = node_root.getElementsByTagName('NHAN_VIEN')
for nhan_vien in nhan_vien_s:
    _id = nhan_vien.getAttribute('ID')
    ho_ten = nhan_vien.getAttribute('Ho_ten')
    gioi_tinh = nhan_vien.getAttribute('Gioi_tinh')
    ngay_sinh = nhan_vien.getAttribute('Ngay_sinh')
    cmnd = nhan_vien.getAttribute('CMND')
    muc_luong = nhan_vien.getAttribute('Muc_luong')
    dia_chi = nhan_vien.getAttribute('Dia_chi')
    iddv = nhan_vien.getAttribute('ID_DON_VI')

    # Thực hiện đưa DL vào DB
    chuoi_sql = "INSERT INTO NhanVien VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    conn.execute(chuoi_sql, (_id, ho_ten, gioi_tinh, ngay_sinh, cmnd, muc_luong, dia_chi, iddv))
    conn.commit()

    print("Đã ghi NV" + _id)


# Xóa bảng
# chuoi_sql = "drop table NhanVien"
# conn.execute(chuoi_sql)
# conn.commit()


# Ngắt kết nối DB
conn.close()