from thu_vien.c_Database import *


class Tivi(Database):
    def __init__(self, path_db):
        Database.__init__(self, path_db)

    def doc_danh_sach_tivi(self):
        chuoi_sql = 'SELECT * FROM Tivi'
        noi_dung = Database.get_all(self, chuoi_sql)
        ds_tivi = []
        for dong in noi_dung:
            tivi = {"Ma_so": dong[0], "Ten": dong[1], "Ky_hieu": dong[2], "Don_gia_Ban": dong[3],
                    "Don_gia_Nhap": dong[4],  "So_luong_Ton": dong[5], "Nhom_Tivi": dong[6]}
            ds_tivi.append(tivi)
        return ds_tivi

    def them_tivi(self, ma_so, ten, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi):
        chuoi_sql = "INSERT INTO Tivi VALUES (?, ?, ?, ?, ?, ?, ?)"
        kq = Database.execute(self, chuoi_sql, (ma_so, ten, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi))
        return kq

    def cap_nhat_tivi(self, ma_so, ten, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi):
        chuoi_sql = "UPDATE Tivi SET Ten=?, Ky_hieu=?, Don_gia_Ban=?, Don_gia_Nhap=?, So_luong_Ton=?," \
                    "Nhom_Tivi=? WHERE Ma_so=?"
        kq = Database.execute(self, chuoi_sql, (ten, ky_hieu, don_gia_ban, don_gia_nhap, so_luong_ton, nhom_tivi, ma_so))
        return kq

    def xoa_tivi(self, ma_so):
        chuoi_sql = "DELETE FROM Tivi WHERE Ma_so=?"
        kq = Database.execute(self, chuoi_sql, (ma_so,))
        return kq

    def tim_kiem_tivi(self, tu_khoa):
        chuoi_dk = "%" + tu_khoa + "%"
        chuoi_sql = 'SELECT * FROM Tivi WHERE Ten like ?'
        noi_dung = Database.get_all(self, chuoi_sql, (chuoi_dk,))
        ds_tivi = []
        for dong in noi_dung:
            tivi = {"Ma_so": dong[0], "Ten": dong[1], "Ky_hieu": dong[2], "Don_gia_Ban": dong[3],
                    "Don_gia_Nhap": dong[4], "So_luong_Ton": dong[5], "Nhom_Tivi": dong[6]}
            ds_tivi.append(tivi)
        return ds_tivi
