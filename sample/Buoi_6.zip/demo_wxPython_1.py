import wx


app = wx.App()
frame = wx.Frame(None, title="Demo wxPython 1", size=(500, 400))
panel = wx.Panel(frame)
label = wx.StaticText(panel, label="Hello cả lớp", pos=(100, 50))
frame.Show(True)
app.MainLoop()
