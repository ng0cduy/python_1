import wx


def on_click(self):
    # button.Destroy()
    button.SetBitmap(image_2)


app = wx.App()
frame = wx.Frame(None, title="Demo BitmapButton", size=(500, 500))
panel = wx.Panel(frame, -1)

image_1 = wx.Image('images/add-1.png', wx.BITMAP_TYPE_ANY).ConvertToBitmap()
image_2 = wx.Image('images/add-2.png', wx.BITMAP_TYPE_ANY).ConvertToBitmap()

button = wx.BitmapButton(panel, -1, image_1, pos=(50, 20))

frame.Bind(wx.EVT_BUTTON, on_click, button)
button.SetDefault()

frame.Show(True)
app.MainLoop()


# http://www.iconarchive.com/show/vista-artistic-icons-by-awicons/add-icon.html
