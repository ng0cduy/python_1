import wx


def on_click(self):
    btn.SetLabel("Đã click")


app = wx.App()
frame = wx.Frame(None, title="Demo Button", size=(500, 400))
panel = wx.Panel(frame)

btn = wx.Button(panel, label='Click để xem KQ', pos=(100, 100))
frame.Bind(wx.EVT_BUTTON, on_click, btn)

frame.Show(True)
app.MainLoop()



