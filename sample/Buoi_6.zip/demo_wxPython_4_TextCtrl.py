import wx


app = wx.App()
frame = wx.Frame(None, title="Demo TextCtrl", size=(500, 400))
panel = wx.Panel(frame)

txt1 = wx.TextCtrl(panel, value="Nhập họ tên", pos=(100, 50), size=(150, 30))
txt2 = wx.TextCtrl(panel, value="123456", style=wx.TE_PASSWORD, pos=(100, 90), size=(150, 30))
txt3 = wx.TextCtrl(panel, value="Không được nhập vào đây", style=wx.TE_READONLY | wx.TE_PASSWORD, pos=(100, 130), size=(150, 30))
print(txt3.GetValue())
txt1.SetValue("Test thử chơi")

frame.Show(True)
app.MainLoop()
