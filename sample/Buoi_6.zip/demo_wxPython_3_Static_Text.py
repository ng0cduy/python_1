import wx

app = wx.App()
frame = wx.Frame(None, title="Demo StaticText", size=(500, 400))
panel = wx.Panel(frame)

label = wx.StaticText(panel, label="Hello cả lớp", style=wx.ALIGN_CENTER, size=(480, 400), pos=(0, 50))

frame.Show(True)
app.MainLoop()
