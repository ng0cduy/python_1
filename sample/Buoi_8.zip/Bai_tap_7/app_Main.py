from giao_dien.gd_Main import *

app = wx.App()
frame = frameMain(None)


frame.Show(True)
app.MainLoop()

