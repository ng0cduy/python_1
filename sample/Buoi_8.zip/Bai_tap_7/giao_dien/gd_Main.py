# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version Oct 26 2018)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

# Thư viện xử lý
from thu_vien.XL_Chung import *
from thu_vien.c_Tivi import *
from thu_vien.c_Cong_ty import *
from thu_vien.c_Nhan_vien import *
from thu_vien.c_Nhom_Tivi import *

# Thư viện giao diện
from giao_dien.gd_Bai_7_1 import *
from giao_dien.gd_Bai_7_2 import *
from giao_dien.gd_Bai_7_3 import *
from giao_dien.gd_Bai_7_4 import *


###########################################################################
## Class frameMain
###########################################################################

class frameMain ( wx.MDIParentFrame ):  # wx.Frame  =>  wx.MDIParentFrame

	def __init__( self, parent ):
		# wx.Frame  =>  wx.MDIParentFrame
		wx.MDIParentFrame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 1000,600 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		self.m_menubar1 = wx.MenuBar( 0 )
		self.m_menu1 = wx.Menu()
		self.menuItemDangNhap = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Đăng nhập", wx.EmptyString, wx.ITEM_CHECK )
		self.m_menu1.Append( self.menuItemDangNhap )

		self.menuItemThoat = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Thoát", wx.EmptyString, wx.ITEM_CHECK )
		self.m_menu1.Append( self.menuItemThoat )

		self.m_menubar1.Append( self.m_menu1, u"Thông tin" )

		self.m_menu2 = wx.Menu()
		self.menuItemThongTinCongTy = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Bài 7.1: Thông tin công ty", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.Append( self.menuItemThongTinCongTy )

		self.menuItemNhomTivi = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Bài 7.2: Nhóm Tivi", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.Append( self.menuItemNhomTivi )

		self.menuItemThemNhanVien = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Bài 7.3: Thêm nhân viên", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.Append( self.menuItemThemNhanVien )

		self.menuItemThemTivi = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Bài 7.4: Thêm Tivi", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.Append( self.menuItemThemTivi )

		self.m_menubar1.Append( self.m_menu2, u"Chức năng" )

		self.m_menu3 = wx.Menu()
		self.menuItemVeChungToi = wx.MenuItem( self.m_menu3, wx.ID_ANY, u"Về chúng tôi", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu3.Append( self.menuItemVeChungToi )

		self.menuItemKiemTraCapNhat = wx.MenuItem( self.m_menu3, wx.ID_ANY, u"Kiểm tra cập nhật", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu3.Append( self.menuItemKiemTraCapNhat )

		self.menuItemPhienBan = wx.MenuItem( self.m_menu3, wx.ID_ANY, u"Phiên bản", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu3.Append( self.menuItemPhienBan )

		self.m_menubar1.Append( self.m_menu3, u"Giúp đỡ" )

		self.SetMenuBar( self.m_menubar1 )


		self.Centre( wx.BOTH )

		# Connect Events
		self.Bind( wx.EVT_MENU, self.menuItemDangNhap_click, id = self.menuItemDangNhap.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemThoat_click, id = self.menuItemThoat.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemThongTinCongTy_click, id = self.menuItemThongTinCongTy.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemNhomTivi_click, id = self.menuItemNhomTivi.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemThemNhanVien_click, id = self.menuItemThemNhanVien.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemThemTivi_click, id = self.menuItemThemTivi.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemVeChungToi_click, id = self.menuItemVeChungToi.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemKiemTraCapNhat_click, id = self.menuItemKiemTraCapNhat.GetId() )
		self.Bind( wx.EVT_MENU, self.menuItemPhienBan_click, id = self.menuItemPhienBan.GetId() )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def menuItemDangNhap_click( self, event ):
		event.Skip()

	def menuItemThoat_click( self, event ):
		event.Skip()

	def menuItemThongTinCongTy_click( self, event ):
		tieu_de = "Thông tin công ty"

		ds_Children = self.GetChildren()
		for children in ds_Children:
			if children.GetTitle() == tieu_de:
				children.Activate()
				return

		# Khởi tạo đối tượng CongTy
		xl_cong_ty = CongTy(duong_dan_cong_ty)
		ds_cong_ty = xl_cong_ty.doc_thong_tin_cong_ty()[0]

		app = wx.App()
		# wx.Frame => wx.MDIChildFrame,  None => self
		frame = wx.MDIChildFrame(self, title=tieu_de, size=(520, 460))
		panel = panel_Bai_7_1(frame)
		panel.txtTen.SetValue(ds_cong_ty['Ten'])
		panel.txtMaSo.SetValue(ds_cong_ty['Ma_so'])
		panel.txtDienThoai.SetValue(ds_cong_ty['Dien_thoai'])
		panel.txtDiaChi.SetValue(ds_cong_ty['Dia_chi'])
		panel.txtEmail.SetValue(ds_cong_ty['Email'])
		frame.Show(True)
		app.MainLoop()
		xl_cong_ty.disconnect()

	def menuItemNhomTivi_click( self, event ):
		tieu_de = "Nhóm Tivi"

		ds_Children = self.GetChildren()
		for children in ds_Children:
			if children.GetTitle() == tieu_de:
				children.Activate()
				return

		# Khởi tạo đối tượng NhomTivi
		xl_nhom_tivi = NhomTivi(duong_dan_tivi)
		ds_nhom_tivi = xl_nhom_tivi.doc_danh_sach_nhom_tivi()

		ds_ten_nhom_tivi = []
		for nhom_tivi in ds_nhom_tivi:
			ds_ten_nhom_tivi.append(nhom_tivi['Ten'])

		# Giao diện
		app = wx.App()
		frame = wx.MDIChildFrame(self, title=tieu_de, size=(520, 320))

		panel = panel_Bai_7_2(frame)
		panel.lstboxDSNhom.Append(ds_ten_nhom_tivi)

		frame.Show(True)
		app.MainLoop()
		xl_nhom_tivi.disconnect()

	def menuItemThemNhanVien_click( self, event ):
		tieu_de = "Thêm nhân viên"

		ds_Children = self.GetChildren()
		for children in ds_Children:
			if children.GetTitle() == tieu_de:
				children.Activate()
				return

		app = wx.App()
		frame = wx.MDIChildFrame(self, title=tieu_de, size=(420, 290))
		panel = panel_Bai_7_3(frame)
		frame.Show(True)
		app.MainLoop()

	def menuItemThemTivi_click( self, event ):
		tieu_de = "Thêm Tivi"

		ds_Children = self.GetChildren()
		for children in ds_Children:
			if children.GetTitle() == tieu_de:
				children.Activate()
				return

		# Khởi tạo NhomTivi
		xl_nhom_tivi = NhomTivi(duong_dan_tivi)
		ds_nhom_tivi = xl_nhom_tivi.doc_danh_sach_nhom_tivi()

		# Lấy ds tên nhóm để hiển thị lên choice
		ds_ten_nhom_tivi = []
		for nhom_tivi in ds_nhom_tivi:
			ds_ten_nhom_tivi.append(nhom_tivi['Ten'])

		# Giao diện
		app = wx.App()
		frame = wx.MDIChildFrame(self, title=tieu_de, size=(520, 280))

		panel = panel_Bai_7_4(frame)
		panel.choiceNhomTivi.Append(ds_ten_nhom_tivi)

		frame.Show(True)
		app.MainLoop()

		xl_nhom_tivi.disconnect()

	def menuItemVeChungToi_click( self, event ):
		event.Skip()

	def menuItemKiemTraCapNhat_click( self, event ):
		event.Skip()

	def menuItemPhienBan_click( self, event ):
		event.Skip()


