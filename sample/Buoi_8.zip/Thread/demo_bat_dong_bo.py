import threading
import requests
import time
from datetime import datetime


def download_file(url, filename):
    print("Start download...")
    r = requests.get(url)
    with open(filename, 'wb') as code:
        code.write(r.content)
    print("Finish download.")


def tinh_toan(a, b):
    tong = a + b
    hieu = a - b
    return tong, hieu


class Download(threading.Thread):
    def __init__(self, url, filename):
        threading.Thread.__init__(self)
        self.url = url
        self.filename = filename

    def run(self):
        download_file(self.url, self.filename)


class TinhToan(threading.Thread):
    def __init__(self, a, b):
        threading.Thread.__init__(self)
        self.a = a
        self.b = b

    def run(self):
        print("\n=== TÍNH TOÁN ===")
        tong, hieu = tinh_toan(self.a, self.b)
        print("Tổng:", tong)
        print("Hiệu:", hieu)
        print("Kết thúc tính toán.")


if __name__ == '__main__':
    bd = time.time()

    # Khai báo biến
    url = "https://www.iso.org/files/live/sites/isoorg/files/archive/pdf/en/annual_report_2009.pdf"
    ten_file = "files/" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".pdf"

    # Khai báo đối tượng
    download = Download(url, ten_file)

    # Tính toán
    # a = int(input("Nhập a: "))
    # b = int(input("Nhập b: "))
    tinh = TinhToan(20, 15)

    # Bắt đầu thread
    download.start()
    tinh.start()

    # Chờ
    download.join()
    tinh.join()

    # Thông báo
    print("\nKẾT THÚC CHƯƠNG TRÌNH")
    kt = time.time()
    print("Tổng thời gian thực hiện:", kt - bd)
