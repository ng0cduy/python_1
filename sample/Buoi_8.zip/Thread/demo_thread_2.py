import threading
import time


def print_time(thread_name, delay, counter):
    count = 0
    while count < counter:
        time.sleep(delay)
        count += 1
        print("%s: %s" % (thread_name, time.ctime(time.time())))


class MyThread(threading.Thread):
    def __init__(self, thread_id, name, counter):
        threading.Thread.__init__(self)
        self.ThreadID = thread_id
        self.Name = name
        self.Counter = counter

    def run(self):
        print("Starting: " + self.Name)
        print_time(thread_name=self.Name, delay=self.Counter, counter=5)
        print("Exiting: " + self.Name)


if __name__ == "__main__":
    bd = time.time()
    thread_1 = MyThread(1, "Thread 1", 2)
    thread_2 = MyThread(2, "Thread 2", 4)

    thread_1.start()
    thread_2.start()

    thread_1.join()
    thread_2.join()

    kt = time.time()
    print("Tổng thời gian thực hiện: ", kt - bd)

    print("Exit main thread")
