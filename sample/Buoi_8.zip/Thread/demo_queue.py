import queue


# # FIFO
# q = queue.Queue()
#
# # Đưa giá trị vào hàng đợi
# for i in range(1, 6):
#     q.put(i)
#
# # Lấy giá trị từ hàng đợi
# while not q.empty():
#     print(q.get())


# LIFO
q = queue.LifoQueue()

# Đưa giá trị vào hàng đợi
for i in range(1, 6):
    q.put(i)

# Lấy giá trị từ hàng đợi
while not q.empty():
    print(q.get())

