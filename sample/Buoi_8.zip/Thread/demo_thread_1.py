import _thread
import time


def print_time(thread_name, delay):
    count = 0
    while count < 5:
        time.sleep(delay)
        count += 1
        print("%s: %s" % (thread_name, time.ctime(time.time())))

    
if __name__ == "__main__":
    try:
        bd = time.time()
        # Xử lý đơn luồng 30.10800004005432
        # print_time("Luồng 1", 2)
        # print_time("Luồng 2", 4)

        # Xử lý đa luồng
        _thread.start_new_thread(print_time, ("Luồng 1", 2))
        _thread.start_new_thread(print_time, ("Luồng 2", 4))
        kt = time.time()
        tong_tg = kt - bd
        print("Tổng thời gian:", tong_tg)
    except:
        print("Không thể bắt đầu.")

    # Giữ cho chương trình chạy
    while 1:
        pass
