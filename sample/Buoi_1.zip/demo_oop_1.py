class XeOto:
    '''
    classdocs: Xây dựng class xử lý về Xe ô tô
    '''
    mau_sac = "Đỏ"
    so_cho = 5
    doi_xe = 2018

    def in_thong_tin(self):
        print("Màu sắc: " + self.mau_sac + "\nSố chỗ ngồi: " + str(self.so_cho))



if __name__ == '__main__':
    oto_1 = XeOto()  # Khởi tạo đối tượng

    # print("Màu sắc: ", oto_1.mau_sac)  # Gọi thuộc tính của đối tượng
    oto_1.in_thong_tin()  # Gọi phương thức của đối tượng

    oto_2 = XeOto()
    oto_2.in_thong_tin()