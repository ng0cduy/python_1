import math

class Triangle:
    '''
    classdocs: Tính chu vi, diện tích hình tam giác
    '''

    # Contructor
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    # Hàm tính chu vi
    def tinh_chu_vi(self):
        cv = self.a + self.b + self.c
        return cv

    # Hàm tính diện tích
    def tinh_dien_tich(self):
        nua_cv = self.tinh_chu_vi() / 2
        dt = math.sqrt(nua_cv * (nua_cv - self.a) * (nua_cv - self.b) * (nua_cv - self.c))
        return dt

    def __del__(self):
        pass
