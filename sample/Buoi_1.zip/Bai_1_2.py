class PhepTinh(object):
    def __init__(self, so_thu_nhat, so_thu_hai):
        self.SoThuNhat = so_thu_nhat
        self.SoThuHai = so_thu_hai

    def tong(self):
        return self.SoThuNhat + self.SoThuHai

    def hieu(self):
        return self.SoThuNhat - self.SoThuHai

    def tich(self):
        return self.SoThuNhat * self.SoThuHai

    def thuong(self):
        return self.SoThuNhat / self.SoThuHai


if __name__ == '__main__':
    a = int(input('Nhập số thứ nhất: '))
    b = int(input('Nhập số thứ hai: '))
    kq = PhepTinh(a, b)
    print('Tổng:', kq.tong())
    print('Hiệu:', kq.hieu())
    print('Tích:', kq.tich())
    print('Thương:', kq.thuong())
