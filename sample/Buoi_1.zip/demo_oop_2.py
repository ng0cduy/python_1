class XeOto:
    '''
    classdocs: Xây dựng class xử lý về Xe ô tô
    '''
    mau_sac = "Đỏ"
    so_cho = 5
    doi_xe = 2018

    def in_thong_tin_1(self):
            print("Màu sắc: " + self.mau_sac + "\nSố chỗ ngồi: " + str(self.so_cho))

    def in_thong_tin_2(self, mau_sac, so_cho, doi_xe):
        print("Màu sắc: " + mau_sac + "\nSố chỗ ngồi: " + str(so_cho))



if __name__ == '__main__':
    oto_1 = XeOto()  # Khởi tạo đối tượng

    # print("Màu sắc: ", oto_1.mau_sac)  # Gọi thuộc tính của đối tượng
    oto_1.in_thong_tin_1()  # Gọi phương thức của đối tượng (không có parameters)
    oto_1.in_thong_tin_2("Xanh", 7, 2019)  # Gọi phương thức của đối tượng (có parameters)