class ConNguoi:
    def __init__(self, ho_ten, ngay_sinh, gioi_tinh):
        self.ho_ten = ho_ten
        self.ngay_sinh = ngay_sinh
        self.gioi_tinh = gioi_tinh

    def in_thong_tin(self):
        print("Họ tên:", self.ho_ten)
        print("Ngày sinh:", self.ho_ten)
        print("Giới tính:", self.gioi_tinh)
        print()

class NhanVien(ConNguoi):
    def __init__(self, ho_ten, ngay_sinh, gioi_tinh, ma_so, luong):
        self.ma_so = ma_so
        self.luong = luong
        ConNguoi.__init__(self, ho_ten, ngay_sinh, gioi_tinh)

    def in_thong_tin(self):
        print("Họ tên:", self.ho_ten)
        print("Ngày sinh:", self.ho_ten)
        print("Giới tính:", self.gioi_tinh)
        print("Mã số:", self.ma_so)
        print("Lương:", self.luong)
        print()

if __name__ == '__main__':
    nv1 = NhanVien("Nguyễn Văn A", "11/11/1991", True, "NV001", 9000000)
    nv2 = NhanVien("Nguyễn Văn B", "12/12/1992", False, "NV002", 8000000)

    nv1.in_thong_tin()
    nv2.in_thong_tin()
        

    a = 1
    print(a)