import math


class Polygon(object):
    def __init__(self, so_canh):
        self.so_canh = so_canh
        self.canh = []

    def nhap_canh(self):
        self.canh = [int(input("Nhập cạnh thứ " + str(i + 1) + ": ")) for i in range(self.so_canh)]

    def hien_thi_canh(self):
        for i in range(self.so_canh):
            print("Cạnh " + str(i + 1) + ": " + str(self.canh[i]))


class Triangle(Polygon):
    def __init__(self):
        Polygon.__init__(self, 3)

    def tinh_chu_vi(self):
        a, b, c = self.canh
        cv = a + b + c
        return cv

    def tinh_dien_tich(self):
        a, b, c = self.canh
        nua_cv = self.tinh_chu_vi() / 2
        dt = math.sqrt(nua_cv * (nua_cv - a) * (nua_cv - b) * (nua_cv - c))
        return dt

    def in_thong_tin(self):
        print("Chu vi hình tam giác:", self.tinh_chu_vi())
        print("Diện tích hình tam giác:", self.tinh_dien_tich())
        


if __name__ == '__main__':
    tam_giac = Triangle()
    tam_giac.nhap_canh()
    tam_giac.hien_thi_canh()
    tam_giac.in_thong_tin()
    