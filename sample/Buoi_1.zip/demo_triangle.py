
from thu_vien.my_module import *


if __name__ == '__main__':
    # Nhập liệu
    canh_1 = int(input("Nhập cạnh 1: "))
    canh_2 = int(input("Nhập cạnh 2: "))
    canh_3 = int(input("Nhập cạnh 3: "))

    # Khởi tạo đối tượng
    tam_giac_1 = Triangle(canh_1, canh_2, canh_3)

    # In thông tin chu vi, diện tích
    # print("Chu vi tam giác: ", tam_giac_1.tinh_chu_vi())
    # print("Diện tích tam giác: ", tam_giac_1.tinh_dien_tich())

    # print(getattr(tam_giac_1, "a"))
    # print(hasattr(tam_giac_1, "b"))
    # print(hasattr(tam_giac_1, "d"))
    # setattr(tam_giac_1, "a", 10)


    print(getattr(tam_giac_1, "a"))