class XeOto():
    '''
    classdocs: Xây dựng class xử lý về Xe ô tô
    '''
    def __init__(self, _mau_sac, _so_cho, _doi_xe):  # không bao giờ có giá trị trả về => return
        self.mau_sac = _mau_sac
        self.so_cho = _so_cho
        self.doi_xe = _doi_xe

    def in_thong_tin_1(self):
        print("Màu sắc: " + self.mau_sac + "\nSố chỗ ngồi: " + str(self.so_cho))

    def in_thong_tin_2(self, mau_sac, so_cho, doi_xe):
        print("Màu sắc: " + mau_sac + "\nSố chỗ ngồi: " + str(so_cho))



if __name__ == '__main__':
    oto_1 = XeOto("Vàng", 9, 2020)  # Khởi tạo đối tượng

    # print("Màu sắc: ", oto_1.mau_sac)  # Gọi thuộc tính của đối tượng
    oto_1.in_thong_tin_1()  # Gọi phương thức của đối tượng (không có parameters)
    oto_1.in_thong_tin_2("Xanh", 7, 2019)  # Gọi phương thức của đối tượng (có parameters)