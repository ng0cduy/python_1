class PhuongTrinhBacNhat(object):
    def __init__(self, _a, _b):
        self.a = _a
        self.b = _b

    def tinh_nghiem(self):
        if self.a != 0:
            return -self.b / self.a
        else:
            if self.b == 0:
                return "Phương trình có vô số nghiệm"
            else:
                return "Phương trình vô nghiệm"


    def in_nghiem(self):
        print("Kết quả:", self.tinh_nghiem())


if __name__ == "__main__":
    a = eval(input("Nhập a: "))
    b = eval(input("Nhập b: "))
    ptb1 = PhuongTrinhBacNhat(a, b)
    ptb1.in_nghiem()

